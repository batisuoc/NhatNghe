<?php
define('_to_name', 'QuanticaLabs@gmail.com');
define('_to_email', 'quanticalabs@gmail.com');

define('_smtp_host', '');
define('_smtp_username', '');
define('_smtp_password', '');
define('_smtp_port', '');
define('_smtp_secure', ''); //ssl or tls

define('_subject_email', 'PressRoom: Contact from WWW');

define('_def_name', 'Your Name *');
define('_def_email', 'Your Email *');
define('_def_subject', 'Subject');
define('_def_message', 'Message *');

define('_msg_invalid_data_name', 'Please enter your name.');
define('_msg_invalid_data_email', 'Please enter valid e-mail.');
define('_msg_invalid_data_message', 'Please enter your message.');


define('_msg_send_ok', 'Thank you for contacting us.');
define('_msg_send_error', 'Sorry, we can\'t send this message.');
?>
