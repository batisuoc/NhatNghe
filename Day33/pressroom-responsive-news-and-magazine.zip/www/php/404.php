<div class="page">
	<div class="page_header clearfix page_margin_top">
		<div class="page_header_left">
			<h1 class="page_title">Error 404</h1>
		</div>
		<div class="page_header_right">
			<ul class="bread_crumb">
				<li>
					<a title="Home" href="?page=home">
						Home
					</a>
				</li>
				<li class="separator icon_small_arrow right_gray">
					&nbsp;
				</li>
				<li>
					Error 404
				</li>
			</ul>
		</div>
	</div>
	<div class="page_layout clearfix">
		<div class="divider_block clearfix">
			<hr class="divider first">
			<hr class="divider subheader_arrow">
			<hr class="divider last">
		</div>
		<div class="row page_margin_top">
			<div class="column column_2_3">
				<div class="item_content clearfix">
					<span class="features_icon not_found animated_element animation-scale"></span>
					<div class="text">
						<h1 class="about_title">Page</h1>
						<h1 class="about_subtitle">Not Found</h1>
					</div>
				</div>
				<h3 class="page_margin_top">We're sorry but we can't seem find the page you requested.<br>This might be because you have typed the web address incorrectly.</h3>
				<p class="padding_top_30">In the meantime, try one of options listed below:</p>
				<h3 class="margin_top_20">Go To Page:</h3>
				<ul class="list no_border indent spacing">
					<li class="bullet style_2"><a title="Home" href="?page=home">Home Page</a></li>
					<li class="bullet style_2"><a title="Blog" href="?page=blog">Blog</a></li>
					<li class="bullet style_2"><a title="Contact" href="?page=contact">Contact</a></li>
				</ul>
			</div>
			<div class="column column_1_3">
				<h4 class="box_header">Latest Posts</h4>
				<div class="vertical_carousel_container clearfix">
					<ul class="blog small vertical_carousel autoplay-1 scroll-1 navigation-1 easing-easeInOutQuint duration-750">
						<li class="post">
							<a href="?page=post_gallery" title="Study Linking Illnes and Salt Leaves Researchers Doubtful">
								<span class="icon small gallery"></span>
								<img src='images/samples/100x100/image_06.jpg' alt='img'>
							</a>
							<div class="post_content">
								<h5>
									<a href="?page=post_gallery" title="Study Linking Illnes and Salt Leaves Researchers Doubtful">Study Linking Illnes and Salt Leaves Researchers Doubtful</a>
								</h5>
								<ul class="post_details simple">
									<li class="category"><a href="?page=category&amp;cat=health" title="HEALTH">HEALTH</a></li>
									<li class="date">
										10:11 PM, Feb 02
									</li>
								</ul>
							</div>
						</li>
						<li class="post">
							<a href="?page=post" title="Syrian Civilians Trapped For Months Continue To Be Evacuated">
								<img src='images/samples/100x100/image_12.jpg' alt='img'>
							</a>
							<div class="post_content">
								<h5>
									<a href="?page=post" title="Syrian Civilians Trapped For Months Continue To Be Evacuated">Syrian Civilians Trapped For Months Continue To Be Evacuated</a>
								</h5>
								<ul class="post_details simple">
									<li class="category"><a href="?page=category&amp;cat=world" title="WORLD">WORLD</a></li>
									<li class="date">
										10:11 PM, Feb 02
									</li>
								</ul>
							</div>
						</li>
						<li class="post">
							<a href="?page=post_small_image" title="Built on Brotherhood, Club Lives Up to Name">
								<img src='images/samples/100x100/image_02.jpg' alt='img'>
							</a>
							<div class="post_content">
								<h5>
									<a href="?page=post_small_image" title="Built on Brotherhood, Club Lives Up to Name">Built on Brotherhood, Club Lives Up to Name</a>
								</h5>
								<ul class="post_details simple">
									<li class="category"><a href="?page=category&amp;cat=sports" title="SPORTS">SPORTS</a></li>
									<li class="date">
										10:11 PM, Feb 02
									</li>
								</ul>
							</div>
						</li>
						<li class="post">
							<a href="?page=post" title="Nuclear Fusion Closer to Becoming a Reality">
								<img src='images/samples/100x100/image_13.jpg' alt='img'>
							</a>
							<div class="post_content">
								<h5>
									<a href="?page=post" title="Nuclear Fusion Closer to Becoming a Reality">Nuclear Fusion Closer to Becoming a Reality</a>
								</h5>
								<ul class="post_details simple">
									<li class="category"><a href="?page=category&amp;cat=science" title="SCIENCE">SCIENCE</a></li>
									<li class="date">
										10:11 PM, Feb 02
									</li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
				<h4 class="box_header page_margin_top_section">Most Commented</h4>
				<div class="vertical_carousel_container clearfix">
					<ul class="blog small vertical_carousel autoplay-1 scroll-1 navigation-1 easing-easeInOutQuint duration-750">
						<li class="post">
							<a href="?page=post_gallery" title="Study Linking Illnes and Salt Leaves Researchers Doubtful">
								<span class="icon small gallery"></span>
								<img src='images/samples/100x100/image_06.jpg' alt='img'>
							</a>
							<div class="post_content">
								<h5>
									<a href="?page=post_gallery" title="Study Linking Illnes and Salt Leaves Researchers Doubtful">Study Linking Illnes and Salt Leaves Researchers Doubtful</a>
								</h5>
								<ul class="post_details simple">
									<li class="category"><a href="?page=category&amp;cat=health" title="HEALTH">HEALTH</a></li>
									<li class="date">
										10:11 PM, Feb 02
									</li>
								</ul>
							</div>
						</li>
						<li class="post">
							<a href="?page=post_small_image" title="Syrian Civilians Trapped For Months Continue To Be Evacuated">
								<img src='images/samples/100x100/image_12.jpg' alt='img'>
							</a>
							<div class="post_content">
								<h5>
									<a href="?page=post_small_image" title="Syrian Civilians Trapped For Months Continue To Be Evacuated">Syrian Civilians Trapped For Months Continue To Be Evacuated</a>
								</h5>
								<ul class="post_details simple">
									<li class="category"><a href="?page=category&amp;cat=world" title="WORLD">WORLD</a></li>
									<li class="date">
										10:11 PM, Feb 02
									</li>
								</ul>
							</div>
						</li>
						<li class="post">
							<a href="?page=post" title="Built on Brotherhood, Club Lives Up to Name">
								<img src='images/samples/100x100/image_02.jpg' alt='img'>
							</a>
							<div class="post_content">
								<h5>
									<a href="?page=post" title="Built on Brotherhood, Club Lives Up to Name">Built on Brotherhood, Club Lives Up to Name</a>
								</h5>
								<ul class="post_details simple">
									<li class="category"><a href="?page=category&amp;cat=sports" title="SPORTS">SPORTS</a></li>
									<li class="date">
										10:11 PM, Feb 02
									</li>
								</ul>
							</div>
						</li>
						<li class="post">
							<a href="?page=post_quote_2" title="Nuclear Fusion Closer to Becoming a Reality">
								<img src='images/samples/100x100/image_13.jpg' alt='img'>
							</a>
							<div class="post_content">
								<h5>
									<a href="?page=post_quote_2" title="Nuclear Fusion Closer to Becoming a Reality">Nuclear Fusion Closer to Becoming a Reality</a>
								</h5>
								<ul class="post_details simple">
									<li class="category"><a href="?page=category&amp;cat=science" title="SCIENCE">SCIENCE</a></li>
									<li class="date">
										10:11 PM, Feb 02
									</li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>