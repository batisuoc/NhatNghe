<?php

define("DBHOST", "localhost");
define("DBNAME", "news");
define("DBUSER", "root");
define("DBPASS", "");

?>