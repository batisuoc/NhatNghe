<ul class="list">
	<li class="header">CHUYÊN MỤC</li>
	<li class="active">
		<a href="index.php">
			<i class="material-icons">home</i>
			<span>Trang chủ</span>
		</a>
	</li>
	<li>
		<a href="pages/thoat.php">
			<i class="material-icons">text_fields</i>
			<span>Thoát</span>
		</a>
	</li>
	<li>
		<a href="javascript:void(0);" class="menu-toggle">
			<i class="material-icons">view_list</i>
			<span>Thể loại</span>
		</a>
		<ul class="ml-menu">
			<li>
				<a href="?p=theloai_them">Thêm thể loại</a>
			</li>
			<li>
				<a href="?p=theloai_ds">Danh sách thể loại</a>
			</li>
		</ul>
	</li>
</ul>