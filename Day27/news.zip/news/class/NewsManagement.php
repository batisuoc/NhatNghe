<?php

require "DBConnection.php";

class NewsManagement extends DBConnection
{
	function __construct()
	{
		# code...
	}
}

?>