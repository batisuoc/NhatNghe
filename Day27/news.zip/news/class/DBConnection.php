<?php

require_once "../db/config.php";

class DBConnection
{
	protected $db;

	function __construct()
	{
		$this->db = new mysqli(DBHOST, DBUSER, DBPASS, DBNAME);
		$this->db->set_charset("utf8");
	}
}

?>