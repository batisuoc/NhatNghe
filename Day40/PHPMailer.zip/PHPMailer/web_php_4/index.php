<?php
	session_start();
	ob_start();
	if (!isset($_SESSION["somathang"])) {
		$_SESSION["somathang"]=0; }
	$tong=0;
	for($i=1;$i<=$_SESSION["somathang"];$i++) {
		$tong=$tong+$_SESSION["gia".$i]*$_SESSION["soluong".$i] ;
	$_SESSION['tonggia']=$tong;
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="lightbox2-master/dist/css/lightbox.min.css">

<!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->

<title>HienShOp</title>
<style>
body {
	margin: 0;
	padding: 0;
	color:#FFF;
	background-color:#FCC;
}
#container {
	width: 1024px;
	margin: 0 auto;
	min-height: 800px;
	
	
}
#top {
	width: 100%;
	background-color: #C06;
	margin-bottom: 5px;
	height: 105px;
	color:#FFF;
	//border-bottom:#000 5px double;

}

#tim {
	height: 50px;
	padding-top:70px;
}
#left {
	margin-right: 5%;
	width: 15%;
	float: left;
	//border: 1px solid #000;
	
}
#right {
	width: 15%;
	float: right;
	//height: 600px;
	//background-color: green;
}
#main {
	width: 60%;
	float: left;
}
footer {
	width: 100%;
	height: 120px;
	clear:both;

}
#login {
	width:200px;
	height:100px;
	float: right;
	margin-top: 35px;
	margin-right: 40px;
	//border:#0C3 1px solid;
}
#left_login
{
	width:700px;
	height:100px;
	float:left;	
	//border:#0C3 1px solid;
}
.styletext{
	color:#FFF;
	text-decoration:none;
	font-size:18px;
	line-height:100px;
	}
.styletext:hover{
	color:#FF0;
}
#menu{
	padding-top:20px;
	//padding-left:20px;
	//border:1px solid #000;
	}
#giohang{
	padding-top:50px;
	
}
#qc1{
	margin-top:30px;
	//background-color:#036;
	height:400px;
	
	
	}
#slideanh{
	width:800px;
	height:360px;
	//background-color:#CFC;
	margin:auto;
	}
</style>

</head>

<body>
<?php
	include('dbcon.php');
	$s="select * from webtm_sanpham order by Gia desc limit 0,6"; // 6 san pham co gia cao nhat
	$kq=mysql_query($s,$link);
?>

    <div id="top">
    	<div id="left_login">
        	<a style="text-decoration:none; color:#FFF; text-indent:350px; font-size:24px" href="index.php"><h1>HienShOp<span style="font-size:16px; color:#FFF;">&nbsp;&nbsp;&nbsp;&nbsp;Mại dô mại dô!</span></h1></a>
          
        </div>
      	<div id="login">	
        <?php
			if(isset($_SESSION['UserName'])) {
				echo $_SESSION['Hoten'];
		?>
        		<a class="styletext" href="login/thoat.php">&nbsp;&nbsp;&nbsp;&nbsp;Thoát</a>
        <?php
			}
			else {
		?>
				 <a class="styletext" href="index.php?id=dn">Đăng nhập&nbsp;&nbsp;&nbsp;&nbsp;</a>
                 <a class="styletext" href="index.php?id=dk">Đăng kí</a>
        <?php
			}
		?>
        </div>
    </div>
    <div id="container">
    	<div id="tim">
        	<?php
				include('tim.php');
			?>
        </div>
        <div id="left">
        	<div id="menu">
				<?php
                    include('menu.php');
                ?>
        	</div>
        </div>
        <div id="main">
        <?php
			if(!isset($_GET['id']))
			{
				include('spall-2.php');	
			}
			else
			{
				$id=$_GET['id'];
				switch ($id) {
					case "loai":{include('sptheoloai.php'); break;}
					case "tim":{include('kqtim-2.php');break;}
					case "dn":{include('login/dangnhap.php');break;}
					case "dk":{include('login/formdk.php');break;}
					case "giohang":{include('chitietgiohang.php');break;}
					case "donhang":{include('donhang.php');break;}	
					case "chitiet":{include('chitietsp.php'); break;}		
					default: include('spall-2.php');
				}
			}
        ?>
        </div>
        <div id="right">
        	<div id="giohang">
        		<?php include('gh.php'); ?>
        	</div>
            <div id="qc1">
            </div>
        </div>
    </div>
    <footer>
    	<div style="height:73%;background-color:#FCC">
    	
        </div>
        <div style="height:27%; background-color:#C06; font-size:20px; color:#666; text-indent:40px; padding-top:10px;">
        HienShOp <span style="color:#CCC">facebook.com/HienShOp</span>
        </div>
        
    </footer>
   
</body>

</html>