<?php
	//goi thu vien
	include('class.smtp.php');
	include "class.phpmailer.php"; 
	include "functions.php"; 
	$title = 'Hướng dẫn gửi mail bằng phpmailer';
	$content = 'Bạn đang tìm hiểu về cách gửi email bằng php mailler có nội dung đính kèm.';
	$nTo = 'Son';
	$mTo = 'hson.vuidehoc@gmail.com';
	$diachi = 'hson.vuidehoc@gmail.com';
	//test gui mail
	$mail = sendMailAttachment($title, $content, $nTo, $mTo,$diachicc='','hoadon_15332828312.pdf','Day la file dinh kem');
	if($mail==1)
	echo 'mail của bạn đã được gửi đi hãy kiếm tra hộp thư đến để xem kết quả. ';
	else echo 'Co loi!';
?>