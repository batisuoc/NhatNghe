<?php
include('mail/class.smtp.php');
		include "mail/class.phpmailer.php"; 
		include "mail/functions.php"; 
		$title = 'Hướng dẫn gửi mail bằng phpmailer';
		$content = 'Bạn đang tìm hiểu về cách gửi email bằng php mailler trên.';
		$nTo = 'Son';
		$mTo = 'hson.vuidehoc@gmail.com';
		$diachi = 'hson.vuidehoc@gmail.com';
		//test gui mail
		$mail = sendMailAttachment($title, $content, $nTo, $mTo,$diachicc='','hoadon_15332153772.pdf','Day la file dinh kem');
		?>