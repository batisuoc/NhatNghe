<?php
	echo $_SESSION['Hoten'];
	
?>
<a href="login/thoat.php">Thoat</a>
